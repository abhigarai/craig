package database.server;

import java.util.ArrayList;

import model.FindPeopleInformation;
import model.UserInformation;
import model.UserVerification;

public interface Database {
	
	void initDB();

	boolean addUser(UserInformation userInformation);

	boolean deleteUser(String username);

	boolean updateUser(UserInformation userInformation, String currentUsername);

	boolean verifyUser(UserVerification userVerification);

	boolean findPeople(FindPeopleInformation findPeopleInfo,
			String currentUsername);
	
	ArrayList<String> getListOfPeople(String destination, String currentUsername, String date);
}
