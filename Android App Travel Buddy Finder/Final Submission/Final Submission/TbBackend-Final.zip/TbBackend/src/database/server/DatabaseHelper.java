package database.server;

/*
 * Team: NOMADS
 * This class implements all database operations.
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import model.FindPeopleInformation;
import model.UserInformation;
import model.UserVerification;

public class DatabaseHelper implements Database {
	private Connection connection;

	public DatabaseHelper() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String username = "root";
			String password = "root";
			// Get Connection to DB.
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/travel_buddy", username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// initialize database.
	public void initDB() {
		try {
			Statement statement = connection.createStatement();
			String sql1 = "CREATE TABLE userdetails (name VARCHAR(45) NULL, contact VARCHAR(45) NULL, username VARCHAR(45)  NOT NULL PRIMARY KEY, password VARCHAR(45) NULL, destination VARCHAR(45) NULL)";
			statement.executeUpdate(sql1);
			String sql2 = "CREATE TABLE destinationdetails (id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, username VARCHAR(45) NULL, destination VARCHAR(45) NULL, date VARCHAR(45) NULL, FOREIGN KEY(username) REFERENCES userdetails(username) ON DELETE CASCADE ON UPDATE CASCADE) ";
			statement.executeUpdate(sql2);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// add user to database
	public boolean addUser(UserInformation userInformation) {
		try {
			System.out.println("DB addUser");
			String sql = "INSERT INTO userdetails(name,contact,username,password) values(?,?,?,?)";
			PreparedStatement preparedStatement = connection
					.prepareStatement(sql);
			preparedStatement.setString(1, userInformation.getName());
			preparedStatement.setString(2, userInformation.getContact());
			preparedStatement.setString(3, userInformation.getUsername());
			preparedStatement.setString(4, userInformation.getPassword());
			preparedStatement.executeUpdate();
			return true;
		} catch (Exception e) {
			System.out.println("Exception caught in addUser");
			e.printStackTrace();
		}
		return false;
	}

	// delete user from database
	public boolean deleteUser(String username) {
		try {
			String sql = "DELETE FROM userdetails WHERE username = ?";
			PreparedStatement preparedStatement = connection
					.prepareStatement(sql);
			preparedStatement.setString(1, username);
			preparedStatement.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// update user details such as username and password
	public boolean updateUser(UserInformation userInformation,
			String currentUsername) {
		try {
			System.out.println(currentUsername);
			System.out.println(userInformation.getPassword());
			String sql = "UPDATE userdetails SET password = ? WHERE username = ?";
			PreparedStatement preparedStatement = connection
					.prepareStatement(sql);
			preparedStatement.setString(1, userInformation.getPassword());
			preparedStatement.setString(2, currentUsername);
			preparedStatement.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// verify user in order to complete sign in.
	public boolean verifyUser(UserVerification userVerification) {
		try {
			System.out.println("DB verifyuser");
			String sqlQuery1 = "SELECT username FROM userdetails WHERE username = ?";
			PreparedStatement preparedStatement1 = connection
					.prepareStatement(sqlQuery1);
			preparedStatement1.setString(1, userVerification.getUsername());
			ResultSet resultSet1 = preparedStatement1.executeQuery();

			String sqlQuery2 = "SELECT password FROM userdetails WHERE password = ?";
			PreparedStatement preparedStatement2 = connection
					.prepareStatement(sqlQuery2);
			preparedStatement2.setString(1, userVerification.getPassword());
			ResultSet resultSet2 = preparedStatement2.executeQuery();
			if (resultSet1.absolute(1) && resultSet2.absolute(1))
				return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean findPeople(FindPeopleInformation findPeopleInfo,
			String currentUsername) {
		try {
			String sql1 = "INSERT INTO destinationdetails(username,destination,date) values(?,?,?)";
			PreparedStatement preparedStatement1 = connection
					.prepareStatement(sql1);
			preparedStatement1.setString(1, currentUsername);
			preparedStatement1.setString(2, findPeopleInfo.getDestination());
			preparedStatement1.setString(3, findPeopleInfo.getDate());
			preparedStatement1.execute();

			String sql2 = "UPDATE userdetails SET destination = ? WHERE username = ?";
			PreparedStatement preparedStatement2 = connection
					.prepareStatement(sql2);
			preparedStatement2.setString(1, findPeopleInfo.getDestination());
			preparedStatement2.setString(2, currentUsername);
			preparedStatement2.executeUpdate();

			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// get list of people from database.
	public ArrayList<String> getListOfPeople(String destination,
			String currentUsername, String date) {
		try {
			
			String sql2 = "select distinct u.name, u.contact from userdetails u, destinationdetails d where d.destination = ? and d.date=? and u.username <> ? and u.username IN(select d.username from destinationdetails d where d.destination = ? And d.date=?)";
			PreparedStatement preparedStatement2 = connection
					.prepareStatement(sql2);
			preparedStatement2.setString(1, destination);
			preparedStatement2.setString(2, date);
			preparedStatement2.setString(3, currentUsername);
			preparedStatement2.setString(4, destination);
			preparedStatement2.setString(5, date);
			ResultSet rs2 = preparedStatement2.executeQuery();
			ArrayList<String> info = new ArrayList<String>();
			while (rs2.next()) {
				info.add(rs2.getString("name"));
				info.add(rs2.getString("contact"));
			}
			return info;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
