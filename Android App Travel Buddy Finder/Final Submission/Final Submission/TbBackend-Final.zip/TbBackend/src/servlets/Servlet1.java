package servlets;

/*
 * Team: NOMADS
 * This servlet processes GET and POST requests coming from the android client.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.FindPeopleInformation;
import model.UserInformation;
import model.UserVerification;

import org.json.JSONObject;

import com.google.gson.Gson;

import database.server.DatabaseHelper;

/**
 * Servlet implementation class Servlet
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DatabaseHelper dbHelper;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Servlet1() {
		super();
		dbHelper = new DatabaseHelper();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in doget");
		String userInput = request.getParameter("user_input");
		int count=0;
		System.out.println(count);
		System.out.println(userInput);
		while(userInput == null)
			{
			try {
				Thread.sleep(3000);
				count++;
				System.out.println(count);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Looping");
			};
			System.out.println(userInput);
		// dbHelper.initDB();
		//String userInput = request.getParameter("user_input");
		if (userInput.equals("done_with_signup")) 
		{
			response.setCharacterEncoding("utf8");
			response.setContentType("application/json");
			UserInformation user = new UserInformation();
			user.setName(request.getParameter("name"));
			user.setUsername(request.getParameter("username"));
			user.setPassword(request.getParameter("password"));
			user.setContact(request.getParameter("contact"));
			JSONObject obj = new JSONObject();
			boolean flag = dbHelper.addUser(user);
			System.out.println("Hello");
			try {
				if (flag == true) {
					System.out.println(flag);
					obj.put("userSignUp", "done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}

				else {
					System.out.println(flag);
					obj.put("userSignUp", "not done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (userInput.equals("done_with_signIn")) 
		{
			System.out.println("In sign in");
			response.setCharacterEncoding("utf8");
			response.setContentType("application/json");
			UserVerification userVerification = new UserVerification();
			System.out.println(request.getParameter("verifyUsername"));
			userVerification
					.setUsername(request.getParameter("verifyUsername"));
			userVerification
					.setPassword(request.getParameter("verifyPassword"));
			JSONObject obj = new JSONObject();
			boolean flag = dbHelper.verifyUser(userVerification);
			try {
				if (flag == true) {
					System.out.println(flag);
					obj.put("userVerification", "done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}

				else {
					System.out.println(flag);
					obj.put("userVerification", "not done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (userInput.equals("findPeople")) 
		{
			response.setCharacterEncoding("utf8");
			response.setContentType("application/json");
			FindPeopleInformation findPeopleInformation = new FindPeopleInformation();
			findPeopleInformation.setDestination(request.getParameter("destination"));
			findPeopleInformation.setDate(request.getParameter("month")+"/"+request.getParameter("date")+"/"+request.getParameter("year"));
			String currentUsername = request.getParameter("currentUser");
			JSONObject obj = new JSONObject();
			boolean flag = dbHelper.findPeople(findPeopleInformation,
					currentUsername);
			try {
				if (flag == true) {
					System.out.println(flag);
					obj.put("findPeople", "done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}

				else {
					System.out.println(flag);
					obj.put("findPeople", "not done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}



		if (userInput.equals("getListOfPeople")) 
		{
			System.out.println("List of people");
			PrintWriter out = response.getWriter();
			response.setCharacterEncoding("utf8");
			response.setContentType("application/json");
			String currentDestination = request.getParameter("currentDestination");
			String currentUsername = request.getParameter("currentUsername");
			String date = request.getParameter("date");
			System.out.println(currentDestination);
			ArrayList<String> info = new ArrayList<String>();
			info = dbHelper.getListOfPeople(currentDestination, currentUsername, date);
			String json = new Gson().toJson(info);
			System.out.println(json);
			System.out.println(info.size());
			System.out.println(json.length());
			out.println(json);
			out.flush();
		}

		if (userInput.equals("deleteAccount"))
		{
			System.out.println(" inside delete");
			response.setCharacterEncoding("utf8");
			response.setContentType("application/json");
			String currentUsername = request.getParameter("username");
			System.out.println(currentUsername);
			JSONObject obj = new JSONObject();
			boolean flag = dbHelper.deleteUser(currentUsername);
			try {
				if (flag == true) {
					System.out.println(flag);
					obj.put("deletionDone", "done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}

				else {
					System.out.println(flag);
					obj.put("deletionDone", "not done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (userInput.equals("changeAccountDetails"))
		{
			System.out.println("inside update");
			response.setCharacterEncoding("utf8");
			response.setContentType("application/json");
			UserInformation user = new UserInformation();
			user.setPassword(request.getParameter("password"));
			String currentUsername = (request.getParameter("currentUsername"));
			JSONObject obj = new JSONObject();
			boolean flag = dbHelper.updateUser(user,currentUsername);
			try {
				if (flag == true) {
					System.out.println(flag);
					obj.put("updateDone", "done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}

				else {
					System.out.println(flag);
					obj.put("updateDone", "not done");
					PrintWriter out = response.getWriter();
					out.println(obj);
					out.flush();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
