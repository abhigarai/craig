package services.remote;

import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.methods.HttpGet;

import android.os.AsyncTask;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import entities.CreateProfile;
import entities.PopulateInformation;
import serviceAPI.SignUp;

/**
 * Created by Preeti
 */
public class SignUpService extends AsyncTask<PopulateInformation, Void, String> {
    private SignUp listener;

    public SignUpService(SignUp listener){
        this.listener = listener;
    }

    // works on a background thread to communicate with the server.
    @Override
    protected String doInBackground(PopulateInformation... populateInformations) {
        try {
            HttpResponse response = null;
            String localIP = "128.237.202.177";
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair("name", populateInformations[0].getU().getName()));
            params.add(new BasicNameValuePair("username", populateInformations[0].getU().getUsername()));
            params.add(new BasicNameValuePair("password", populateInformations[0].getU().getPassword()));
            params.add(new BasicNameValuePair("contact", populateInformations[0].getU().getContact()));
            params.add(new BasicNameValuePair("user_input", "done_with_signup"));
            StringBuilder requestURL = new StringBuilder("http://"+localIP+":8080/TbBackend/Servlet1?");
            String queryString = URLEncodedUtils.format(params, "utf-8");
            requestURL.append(queryString);
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(requestURL.toString());
            Log.i("request", request.toString());
            Log.i("requestURL", requestURL.toString());
            response = client.execute(request);
            Log.i("response", response.toString());
            String responseText = EntityUtils.toString(response.getEntity());
            return responseText;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }


    // processes result from the server and calls the completion method.
    @Override
    protected void onPostExecute(String result) {

        listener.SignUpTaskCompletion(result);
    }
}
