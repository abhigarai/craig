package com.nomads.travelbuddy.userinterface;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Toast;

import com.nomads.travelbuddy.R;

import org.json.JSONObject;

import serviceAPI.DeleteAccount;
import services.remote.DeleteAccountService;

/**
 * Created by Preeti
 */
public class DeleteAccountPage extends Activity implements DeleteAccount{
    private Button yesbutton;
    private Button nobutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_account);
        yesbutton= (Button) findViewById(R.id.accept_deletion);
        nobutton= (Button) findViewById(R.id.cancel_deletion);
        yesbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteAccount listener = DeleteAccountPage.this;
                DeleteAccountService runner = new DeleteAccountService(listener);
                runner.setContext(getApplicationContext());
                runner.execute();
            }
        });
        nobutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DeleteAccountPage.this, HomePage.class);
                startActivity(i);
            }
        });
    }

/* Post deletion, redirect to either home page or sign in page depending on the outcome */
    public void DeleteAccountTaskCompletion(String s) {
        try {
            JSONObject obj = new JSONObject(s);
            String checker = obj.getString("deletionDone");
            if (checker.equals("done")) {
                Intent i = new Intent(DeleteAccountPage.this, SignInPage.class);
                Toast.makeText(getApplicationContext(), "Sad to see you go. Join us again soon.", Toast.LENGTH_LONG).show();
                startActivity(i);
            }
            else{
                Toast.makeText(getApplicationContext(), "Error deleting account.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
