package com.nomads.travelbuddy.userinterface;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.telephony.SmsManager;
import android.widget.Toast;

import com.nomads.travelbuddy.R;

import serviceAPI.FindBuddies;
import serviceAPI.ListBuddies;

/**
 * Created by Preeti, this class is not being used in the current implementation
 */
public class SendSMSPage extends Activity{
    Button SendSMS;
    Button AVsms;
    EditText Message;
    TextView PhoneNum;
    private String number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_sms);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            number = extras.getString("number");
        }
        SendSMS = (Button) findViewById(R.id.sendmessage);
        Message = (EditText) findViewById(R.id.message);
        PhoneNum = (TextView) findViewById(R.id.phonenumber);
        PhoneNum.setText(number);
        SendSMS.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           String MSG = Message.getText().toString();
                                           String Phonenumber1 = PhoneNum.getText().toString();
                                           sendMSG(Phonenumber1, MSG);

                                       }
                                   }
        );

    }
    public void sendMSG(String phonenum, String message1)
    {
        String SENT="Message Sent";
        String DELIVERED="Message Delivered";

        PendingIntent sentPI=PendingIntent.getBroadcast(this,0,new Intent(SENT),0);
        PendingIntent deliveredPI=PendingIntent.getBroadcast(this, 0, new Intent(DELIVERED), 0);

        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), "SMS Sent", Toast.LENGTH_LONG).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        Toast.makeText(getBaseContext(), "Generic Failure", Toast.LENGTH_LONG).show();
                        ;
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        Toast.makeText(getBaseContext(), "No Service", Toast.LENGTH_LONG).show();
                        break;

                }
            }
        }, new IntentFilter(SENT));


        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), "SMS Delivered", Toast.LENGTH_LONG).show();
                        break;
                    case Activity.RESULT_CANCELED:
                        Toast.makeText(getBaseContext(), "SMS Not Delivered", Toast.LENGTH_LONG).show();
                        break;


                }
            }
        },new IntentFilter(DELIVERED));

        SmsManager sms=SmsManager.getDefault();
        if(message1.length() == 0) {
            Toast.makeText(getApplicationContext(), "Please enter a message.", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(SendSMSPage.this, ListBuddiesPage.class);
            startActivity(i);
        }
        else {
            sms.sendTextMessage(phonenum, null, message1, sentPI, deliveredPI);
            Intent i = new Intent(SendSMSPage.this, FindBuddiesPage.class);
            startActivity(i);
        }

    }
    }

