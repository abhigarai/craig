package com.nomads.travelbuddy.userinterface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.nomads.travelbuddy.R;

/**
 * Created by Preeti
 * The user is directed here after successful sign in
 */
public class HomePage extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    public void findBuddies (View view) {
        Intent intent = new Intent(this, FindBuddiesPage.class);
        startActivity(intent);
    }

    /* less frequently used options like sign out, delete and update profile*/

    public boolean onCreateOptionsMenu (Menu menu){
        getMenuInflater().inflate(R.menu.menu_home_page, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.signout) {
            Intent i = new Intent(this, SignInPage.class);
            startActivity(i);
            return true;
        }

        if(id == R.id.delete_menu) {
            Intent i = new Intent(this,DeleteAccountPage.class);
            startActivity(i);
        }

        if(id == R.id.update_menu){
            Intent i = new Intent(this, UpdateProfilePage.class);
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }
}
