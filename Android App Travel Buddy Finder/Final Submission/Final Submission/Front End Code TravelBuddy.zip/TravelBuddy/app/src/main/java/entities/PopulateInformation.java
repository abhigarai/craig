package entities;

/**
 * Created by Preeti
 * Is exposed to the Presentation layer, empty class
 */
public class PopulateInformation extends BaseClass implements CreateProfile, CreateAuth, CreateBuddyInfo {

    public PopulateInformation () {
        super();
    }

}
