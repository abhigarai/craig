package entities;

/**
 * Created by Preeti
 */
public interface CreateBuddyInfo {
    public abstract void createBuddyInfo(String p, String q, String r, String s);
}
