package serviceAPI;

/**
 * Created by Preeti
 */
public interface ListBuddies {
    public abstract void ListBuddiesTaskCompletion(String res);
}
