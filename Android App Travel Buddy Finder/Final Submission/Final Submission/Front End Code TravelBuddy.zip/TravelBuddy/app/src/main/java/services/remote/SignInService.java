package services.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;
import java.util.List;

import entities.PopulateInformation;
import serviceAPI.SignIn;

/**
 * Created by Preeti
 */
public class SignInService extends AsyncTask<PopulateInformation, Void, String >  {
    private SignIn listener;
    private SharedPreferences sharedPref;


    public SignInService(SignIn listener) {
    this.listener = listener;
    }

    public void setContext(Context context){
        sharedPref = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
    }

    @Override
    /* Connect to the backend in the background, not visible to the user*/
    protected String doInBackground(PopulateInformation... populateInformations) {
        try {
            HttpResponse response = null;
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair("verifyUsername", populateInformations[0].getU().getUsername()));
            params.add(new BasicNameValuePair("verifyPassword", populateInformations[0].getU().getPassword()));
            params.add(new BasicNameValuePair("user_input", "done_with_signIn"));
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString("username", populateInformations[0].getU().getUsername());
            editor.apply();
            String localIP = "128.237.202.177";
            StringBuilder requestURL = new StringBuilder("http://" + localIP + ":8080/TbBackend/Servlet1?");
            String queryString = URLEncodedUtils.format(params, "utf-8");
            requestURL.append(queryString);
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(requestURL.toString());
            response = client.execute(request);
            String responseText = EntityUtils.toString(response.getEntity());
            return responseText;
        } catch (Exception e){
            Log.e("exceptions", e.getMessage());
        }

        return null;
    }

    @Override
    protected void onPostExecute (String result) {
        listener.SignInTaskCompletion(result);

    }
}
