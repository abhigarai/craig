package com.nomads.travelbuddy.userinterface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.nomads.travelbuddy.R;

import org.json.JSONObject;

import entities.CreateAuth;
import entities.PopulateInformation;
import exceptions.CustomExceptions;
import serviceAPI.UpdateProfile;
import services.remote.UpdateProfileService;

/**
 * Created by Preeti
 */
public class UpdateProfilePage extends Activity implements UpdateProfile{
    private EditText username;
    private EditText password;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);
    }

    public void submitUpdation (View view) {
        try {
        username = ((EditText) findViewById(R.id.type_username_change));
        password = ((EditText) findViewById(R.id.type_password_change));
        String usernameString = username.getText().toString();
        String passwordString = password.getText().toString();
        PopulateInformation populateInformation = new PopulateInformation();
        CreateAuth ca = populateInformation;
        ca.createAuth(usernameString, passwordString);
        if (!(usernameString.equals(passwordString)))
            throw new CustomExceptions();
        UpdateProfile listener = this;
        UpdateProfileService runner = new UpdateProfileService(listener);
        runner.setContext(getApplicationContext());
        runner.execute(populateInformation);
    }
    catch(CustomExceptions e){
        e.UpdateProfileError(getApplicationContext());
    }

    }

    public void updateProfileCompletion (String result) {
        try {

            JSONObject obj = new JSONObject(result);
            String checker = obj.getString("updateDone");
            if(checker.equals("done")) {
                Intent i = new Intent(UpdateProfilePage.this, SignInPage.class);
                Toast.makeText(getApplicationContext(), "Your details have been successfully changed.", Toast.LENGTH_LONG).show();
                startActivity(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Intent i = new Intent(UpdateProfilePage.this, SignInPage.class);
        Toast.makeText(getApplicationContext(), "Your details have been successfully changed.", Toast.LENGTH_LONG).show();
    }
}
