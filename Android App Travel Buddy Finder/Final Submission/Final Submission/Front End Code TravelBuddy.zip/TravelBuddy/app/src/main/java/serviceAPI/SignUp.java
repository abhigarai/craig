package serviceAPI;

/**
 * Created by Preeti
 */
public interface SignUp {
    public abstract void SignUpTaskCompletion(String result);

}
