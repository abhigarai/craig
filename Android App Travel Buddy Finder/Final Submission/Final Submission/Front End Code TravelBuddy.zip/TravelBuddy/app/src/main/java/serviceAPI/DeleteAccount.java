package serviceAPI;

/**
 * Created by Preeti
 */
public interface DeleteAccount {
    public abstract void DeleteAccountTaskCompletion(String res);
}
