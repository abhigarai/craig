package serviceAPI;

/**
 * Created by Preeti
 */
public interface FindBuddies {

    public abstract void FindBuddiesTaskCompletion(String res);
}
