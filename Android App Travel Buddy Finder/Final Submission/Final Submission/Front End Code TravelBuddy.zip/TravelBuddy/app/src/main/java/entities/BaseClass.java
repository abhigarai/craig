package entities;

/**
 * Created by Preeti
 * Implements all business logic
 */
public abstract class BaseClass {
    private User u;
    private Buddy b;

    public void createProfile(String name, String contact, String username, String password){
        u=new User();
        u.setName(name);
        u.setContact(contact);
        u.setUsername(username);
        u.setPassword(password);
    }

    public void createAuth(String username, String password) {
        u = new User();
        u.setUsername(username);
        u.setPassword(password);
    }

    public void findBuddyInfo(String destination) {
        b.setDestination(destination);
    }

    public void createBuddyInfo(String p, String q, String r, String s) {
        b = new Buddy();
        b.setDestination(p);
        b.setYear(q);
        b.setMonth(r);
        b.setDate(s);

    }

    public User getU() {
        return u;
    }

    public Buddy getB() {
        return b;
    }
}
