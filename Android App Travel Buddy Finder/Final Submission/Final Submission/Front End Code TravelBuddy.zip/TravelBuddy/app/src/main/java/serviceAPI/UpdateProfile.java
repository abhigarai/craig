package serviceAPI;

/**
 * Created by Preeti
 */
public interface UpdateProfile {
    public abstract void updateProfileCompletion (String result);
}
