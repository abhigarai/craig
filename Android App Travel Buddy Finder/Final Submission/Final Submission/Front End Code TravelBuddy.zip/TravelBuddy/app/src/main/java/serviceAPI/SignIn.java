package serviceAPI;

/**
 * Created by Preeti
 */
public interface SignIn {
    public abstract void SignInTaskCompletion(String res);
}
