package com.nomads.travelbuddy.userinterface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.nomads.travelbuddy.R;

import org.json.JSONException;
import org.json.JSONObject;

import entities.CreateAuth;
import entities.CreateProfile;
import entities.PopulateInformation;
import exceptions.CustomExceptions;
import serviceAPI.SignUp;
import services.remote.SignUpService;

/**
 * Created by Preeti
 */
public class SignUpPage extends Activity implements SignUp {
    private EditText name;
    private EditText contact;
    private EditText username;
    private EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
    }

    public  void submit(View view) {
        try {
            name = ((EditText) findViewById(R.id.type_name_sign_up));
            contact = ((EditText) findViewById(R.id.contactnum_sign_up));
            username = ((EditText) findViewById(R.id.username_sign_up));
            password = ((EditText) findViewById(R.id.password_sign_up));
            String nameString = name.getText().toString();
            String contactString = contact.getText().toString();
            String usernameString = username.getText().toString();
            String passwordString = password.getText().toString();
            if (nameString.length() == 0 || contactString.length() == 0 || usernameString.length() == 0 || passwordString.length() == 0)
                throw new CustomExceptions();
            PopulateInformation populateInformation = new PopulateInformation();

            Log.d("nullptr", populateInformation.toString());
            CreateProfile cp = populateInformation;
            Log.i("nullptr", cp.toString());
            cp.createProfile(nameString, contactString, usernameString, passwordString);
            SignUp listener = this;
            SignUpService runner = new SignUpService(listener);
            runner.execute(populateInformation);
        }
        catch(CustomExceptions e)
        {
            Log.d("exceptions", e.getMessage());
            e.SignUpError(getApplicationContext());
        }

    }


    public void SignUpTaskCompletion (String result) {

        try{

            Log.i("json1", result.toString());
            JSONObject obj = new JSONObject(result);
            String checker = obj.getString("userSignUp");
            if(checker.equals("done")) {
                Intent home_intent = new Intent(SignUpPage.this, SignInPage.class);
                Toast.makeText(getApplicationContext(), "You are successfully registered. Please sign in using your credentials", Toast.LENGTH_LONG).show();
                startActivity(home_intent);
            }
            else
                throw new CustomExceptions();
        }
        catch (CustomExceptions e) {
            e.SignUpError(getApplicationContext());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}
