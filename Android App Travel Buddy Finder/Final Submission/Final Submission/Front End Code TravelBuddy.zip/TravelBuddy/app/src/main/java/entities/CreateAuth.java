package entities;

/**
 * Created by Preeti
 */
public interface CreateAuth {
    public abstract void createAuth(String username, String password);
}
