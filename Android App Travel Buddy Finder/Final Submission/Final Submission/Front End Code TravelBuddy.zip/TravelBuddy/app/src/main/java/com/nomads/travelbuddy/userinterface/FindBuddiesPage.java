package com.nomads.travelbuddy.userinterface;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import com.nomads.travelbuddy.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

import entities.CreateBuddyInfo;
import entities.PopulateInformation;
import exceptions.CustomExceptions;
import serviceAPI.FindBuddies;
import services.remote.FindBuddiesService;

/**
 * Created by Preeti on
 */
public class FindBuddiesPage extends Activity implements FindBuddies{
    private EditText dest;
    private DatePicker datePicker;
    private Calendar calendar;
    private int year, month, day;
    private int travelyear, travelmonth, travelday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_buddies);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
    }

    public void setDatePicker(View view) {
        showDialog(999);
    }

    /* Setting the Dialog and initializing the picker to not accept past dates*/
    protected Dialog onCreateDialog(int id) {
        if(id == 999) {
            DatePickerDialog dpd = new DatePickerDialog(this, myDateListener, year, month, day);
            dpd.getDatePicker().setMinDate(System.currentTimeMillis() - 3000);
            return dpd;
        }
        return null;
    }
    /* Set the dates uppon user interaction*/
    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener(){

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

            travelyear = year;
            travelmonth = monthOfYear+1;
            travelday = dayOfMonth;

            Log.i("date", travelyear+ " "+ travelmonth+" "+travelday);
        }
    };

    public void find(View view) {
        try {
            dest = ((EditText) findViewById(R.id.type_destination));
            String destString = dest.getText().toString();
            String ty = Integer.toString(travelyear);
            String tm = Integer.toString(travelmonth);
            String td = Integer.toString(travelday);
            Log.i("Date",ty + " "+ tm + " "+ td);
            Log.i("empty values", ty+"/"+tm+"/"+td);
            if (ty.equals("0") || tm.equals("-1") || td.equals("0") || destString.equals(""))
                throw new CustomExceptions();
            SharedPreferences sharedPref = getSharedPreferences("userInfo", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString("destination", destString);
            editor.apply();

        PopulateInformation populateInformation = new PopulateInformation();
        CreateBuddyInfo cbi = populateInformation;
        cbi.createBuddyInfo(destString, ty, tm,td);

        FindBuddies listener = this;
        FindBuddiesService runner = new FindBuddiesService(listener);
        runner.setContext(getApplicationContext());
        runner.execute(populateInformation);
        }catch(CustomExceptions e){
            e.EmptyDestandDateError(getApplicationContext());
        }
    }

    public void FindBuddiesTaskCompletion (String result) {
        try {
            Log.i("json", result.toString());
            JSONObject obj = new JSONObject(result);
            String checker = obj.getString("findPeople");
            if(checker.equals("done")) {
                Intent i = new Intent(this, ListBuddiesPage.class);
                startActivity(i);
            }
            else throw new CustomExceptions();
        } catch(CustomExceptions e) {
            e.EmptyDestandDateError(getApplicationContext());
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
