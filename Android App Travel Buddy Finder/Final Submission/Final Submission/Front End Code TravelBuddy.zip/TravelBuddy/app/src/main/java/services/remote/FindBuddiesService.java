package services.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;
import java.util.List;

import entities.PopulateInformation;
import serviceAPI.FindBuddies;

/**
 * Created by Preeti
 */
public class FindBuddiesService extends AsyncTask<PopulateInformation,Void,String>{
    private SharedPreferences sharedPref;
    private SharedPreferences sharedPref1;
    private SharedPreferences sharedPref2;
    private FindBuddies listener;
    public FindBuddiesService  (FindBuddies listener) {this.listener = listener; }

    public void setContext(Context context){
        sharedPref = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        sharedPref1 = context.getSharedPreferences("destinationInfo", Context.MODE_PRIVATE);
        sharedPref2 = context.getSharedPreferences("date", Context.MODE_PRIVATE);
    }

    @Override
    protected String doInBackground(PopulateInformation... populateInformations) {
        try{
        HttpResponse response = null;
        String localIP = "128.237.202.177";
        String currentUsername = sharedPref.getString("username", "");
        SharedPreferences.Editor editor = sharedPref1.edit();
        editor.putString("destination", populateInformations[0].getB().getDestination());
        SharedPreferences.Editor editor1 = sharedPref2.edit();
        editor1.putString("date", populateInformations[0].getB().getMonth()+"/"+populateInformations[0].getB().getDate()+"/"+populateInformations[0].getB().getYear());
        editor.apply();
        editor1.apply();
        List<NameValuePair> params = new ArrayList<>();
        params.add(new BasicNameValuePair("currentUser", currentUsername));
        params.add(new BasicNameValuePair("destination", populateInformations[0].getB().getDestination()));
        params.add(new BasicNameValuePair("year", populateInformations[0].getB().getYear()));
        params.add(new BasicNameValuePair("month",populateInformations[0].getB().getMonth()));
        params.add(new BasicNameValuePair("date", populateInformations[0].getB().getDate()));
        params.add(new BasicNameValuePair("user_input", "findPeople"));
        StringBuilder requestURL = new StringBuilder("http://"+localIP+":8080/TbBackend/Servlet1?");
        String queryString = URLEncodedUtils.format(params, "utf-8");
        requestURL.append(queryString);
        HttpClient client = new DefaultHttpClient();
        HttpGet request = new HttpGet(requestURL.toString());
        response = client.execute(request);
        String responseText = EntityUtils.toString(response.getEntity());
            Log.i("responseText", responseText.toString());
        return responseText;
    }
    catch(Exception e){
        e.printStackTrace();
    }
    return null;
    }

    protected void onPostExecute(String result){
        listener.FindBuddiesTaskCompletion(result);
    }
}
