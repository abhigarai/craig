package services.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;
import java.util.List;

import serviceAPI.DeleteAccount;

/**
 * Created by Preeti
 * Connect to remote MySQL and deletes accounts
 */
public class DeleteAccountService extends AsyncTask<Void,Void,String> {

    private DeleteAccount listener;

    private SharedPreferences sharedPref;
    public DeleteAccountService(DeleteAccount listener){
        this.listener = listener;
    }

    public void setContext(Context context){
        sharedPref = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
    }

    protected String doInBackground(Void... voids) {
        try {
            Log.i("Inside doBackground", "hi from delete");
            HttpResponse response = null;
            String localIP = "128.237.202.177";
            String currentUsername = sharedPref.getString("username", "");
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair("username", currentUsername));
            params.add(new BasicNameValuePair("user_input", "deleteAccount"));
            StringBuilder requestURL = new StringBuilder("http://"+localIP+":8080/TbBackend/Servlet1");
            String queryString = URLEncodedUtils.format(params, "utf-8");
            requestURL.append("?");
            requestURL.append(queryString);
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(requestURL.toString());
            response = client.execute(request);
            String responseText = EntityUtils.toString(response.getEntity());
            return responseText;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    protected void onPostExecute(String s) {
        listener.DeleteAccountTaskCompletion(s);
    }
}
