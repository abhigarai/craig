package adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.nomads.travelbuddy.R;

import java.util.HashMap;
import java.util.List;

import entities.Buddy;

/**
 * Created by Preeti
 */
public class BuddyAdapter extends BaseExpandableListAdapter{
    private Context ctx;
    private HashMap<String,List<String>> Buddy_Category;
    private List<String> Buddy_list;


    public BuddyAdapter(Context ctx,HashMap<String,List<String>>Buddy_Category, List<String> Buddy_list)
    {
        this.ctx=ctx;
        this.Buddy_Category=Buddy_Category;
        this.Buddy_list=Buddy_list;

    }
    @Override
    public int getGroupCount() {
        return Buddy_list.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return Buddy_Category.get(Buddy_list.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return Buddy_list.get(groupPosition);
    }

    @Override
    public Object getChild(int parent, int child) {
        return Buddy_Category.get(Buddy_list.get(parent)).get(child);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int parent, int child) {
        return child;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    // gives titles or names of each list.
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String group_tilte= (String) getGroup(groupPosition);
        if(convertView==null)
        {
            LayoutInflater inflator= (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflator.inflate(R.layout.parent,parent,false);
        }
        TextView parent_textview= (TextView) convertView.findViewById(R.id.parent_txt);
        parent_textview.setTypeface(null, Typeface.BOLD);
        parent_textview.setText(group_tilte);
        return convertView;
    }

    // gives sub-list of people
    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        String child_title= (String) getChild(groupPosition,childPosition);
        if(convertView==null)
        {
            LayoutInflater inflator= (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflator.inflate(R.layout.child,parent,false);
        }
        TextView child_textview= (TextView) convertView.findViewById(R.id.child_txt);
        child_textview.setText(child_title);
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

}
