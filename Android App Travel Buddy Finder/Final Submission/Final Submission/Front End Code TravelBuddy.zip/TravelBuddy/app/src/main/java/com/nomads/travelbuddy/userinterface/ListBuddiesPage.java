package com.nomads.travelbuddy.userinterface;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.Toast;

import com.nomads.travelbuddy.R;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import adapter.BuddyAdapter;
import entities.CreateBuddyInfo;
import entities.PopulateInformation;
import serviceAPI.ListBuddies;
import services.remote.ListBuddiesService;

/**
 * Created by Preeti
 */
public class ListBuddiesPage extends Activity implements ListBuddies {
    HashMap<String,List<String>> BuddyDetails;
    List<String> Buddy_List;
    BuddyAdapter adapter;
    ExpandableListView Exp_list;
    private String number;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_buddies);

        SharedPreferences sharedPref = getSharedPreferences("destinationInfo", Context.MODE_PRIVATE);
        String currentDestination= sharedPref.getString("destination", "");

        CreateBuddyInfo cbi = new PopulateInformation();
        Exp_list = (ExpandableListView) findViewById(R.id.exp_list);
        ListBuddies listener = this;
        ListBuddiesService runner = new ListBuddiesService(listener);
        runner.setContext(getApplicationContext());
        runner.execute(currentDestination);

    }

    public void ListBuddiesTaskCompletion (String result) {
        try {

            Log.i("json", result.toString());
            JSONArray jsonArray = new JSONArray(result);
            if(jsonArray.length() == 0)
                Toast.makeText(ListBuddiesPage.this, "There is currently no one around. Try again after some time. Thanks.", Toast.LENGTH_LONG).show();
            // Toast.makeText(ListBuddiesPage.this,jsonArray.getString(0), Toast.LENGTH_LONG).show();
            BuddyDetails=new HashMap<String,List<String>>();
            Log.i("arraylength", String.valueOf(jsonArray.length()));
            for(int i = 0 ; i < jsonArray.length();i++){
                ArrayList<String> infoArrayList = new ArrayList<>();
                String name = jsonArray.getString(i);
                i = i + 1;
                infoArrayList.add(0, jsonArray.getString(i));
                infoArrayList.add(1,"Send Message");
                infoArrayList.add(2, "Call");
                //infoArrayList.add(6,"View Gallery");
                BuddyDetails.put(name, infoArrayList);
            }
            Buddy_List=new ArrayList<String>(BuddyDetails.keySet());
            adapter=new BuddyAdapter(ListBuddiesPage.this,BuddyDetails,Buddy_List);
            Exp_list.setAdapter(adapter);
            Exp_list.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
                @Override
                public void onGroupExpand(int groupPosition) {
                    //Toast.makeText(getBaseContext(), People_List.get(groupPosition) + " is selected", Toast.LENGTH_LONG).show();
                }
            });
            Exp_list.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
                @Override
                public void onGroupCollapse(int groupPosition) {
                    //  Toast.makeText(getBaseContext(), People_List.get(groupPosition) + " is collapsed", Toast.LENGTH_LONG).show();
                }
            });
            //this method gets executed when user selects any of the child objects (eg. send message-include messaging capability in this method)
            Exp_list.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
                @Override
                public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

                    Toast.makeText(getBaseContext(),BuddyDetails.get(Buddy_List.get(groupPosition)).get(childPosition), Toast.LENGTH_LONG).show();
                    String hold=BuddyDetails.get(Buddy_List.get(groupPosition)).get(childPosition);
                    Log.i("Debug", hold);
                    number = BuddyDetails.get(Buddy_List.get(groupPosition)).get(0);

                    if(hold.equals("Send Message"))
                    {
                        Log.i("Debug", hold);

                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse("smsto:"));
                        i.setType("vnd.android-dir/mms-sms");
                        i.putExtra("address", number);

                        try {
                            startActivity(i);
                            finish();
                            Log.i("Finished sending SMS...", "");
                        }
                        catch (android.content.ActivityNotFoundException ex) {
                            Toast.makeText(ListBuddiesPage.this,
                                    "SMS failed, please try again later.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    if(hold.equals("Call")){
                        Log.i("Debug", hold);
                        Intent callIntent=  new Intent(Intent.ACTION_CALL, Uri.parse("tel: " + number));
                        startActivity(callIntent);
                    }

                    return false;
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
