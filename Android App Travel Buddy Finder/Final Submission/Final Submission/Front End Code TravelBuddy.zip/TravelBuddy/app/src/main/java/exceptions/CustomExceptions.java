package exceptions;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by Preeti
 * Alternate use cases in case the user is unable to complete the action
 */
public class CustomExceptions extends Exception {

    public void SigninError(Context context) {
        Toast.makeText(context, "Either the username or password is incorrect. Please try again", Toast.LENGTH_LONG).show();
    }

    public void SignUpError(Context context) {
        Toast.makeText(context, "The username already exists. Please try again.", Toast.LENGTH_LONG).show();
    }

    public void UpdateProfileError(Context context) {
        Toast.makeText(context, "Password doesn't match. Please try again.", Toast.LENGTH_LONG).show();
    }

    public void EmptyDestandDateError (Context context){
        Toast.makeText(context, "Please enter destination and date", Toast.LENGTH_LONG).show();
    }

    public void FindByDestinationError(Context context) {
        Toast.makeText(context, "Sorry, we could not find buddies who are going to the same destination", Toast.LENGTH_LONG).show();
    }
}
