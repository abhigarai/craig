package com.nomads.travelbuddy.userinterface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.nomads.travelbuddy.R;

/**
 * The app opens with this activity presented to the viewer first.
 */
public class SplashScreen extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        Thread starttimer = new Thread(){
            public void run() {
                try {
                    sleep(2000);
                    Intent i = new Intent(getBaseContext(), SignInPage.class);
                    startActivity(i);
                    finish();
                } catch (InterruptedException e) {
                    Log.d("Exceptions", e.getMessage());
                }
            }

        };
        starttimer.start();
    }
}
