package services.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;
import java.util.List;

import serviceAPI.ListBuddies;

/**
 * Created by Preeti
 */
public class ListBuddiesService extends AsyncTask<String, Void, String>{
    private ListBuddies listener;
    private SharedPreferences sharedPref;
    private SharedPreferences sharedPref1;

    public ListBuddiesService(ListBuddies listener) {
        this.listener = listener;
    }

    public void setContext(Context context) {
        sharedPref = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        sharedPref1 = context.getSharedPreferences("date", Context.MODE_PRIVATE);
    }

    // works on a background thread to communicate with the server.
    @Override
    protected String doInBackground(String... zipcode) {
        try {
            HttpResponse response = null;
            String localIP = "128.237.202.177";
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair("currentDestination", zipcode[0]));
            String currentUsername = sharedPref.getString("username", "");
            String date = sharedPref1.getString("date", "");
            Log.i("check_date_value", date);
            params.add(new BasicNameValuePair("currentUsername", currentUsername));
            params.add(new BasicNameValuePair("date", date));
            params.add(new BasicNameValuePair("user_input", "getListOfPeople"));
            StringBuilder requestURL = new StringBuilder("http://"+localIP+":8080/TbBackend/Servlet1?");
            String queryString = URLEncodedUtils.format(params, "utf-8");
            requestURL.append(queryString);
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(requestURL.toString());
            response = client.execute(request);
            String responseText = EntityUtils.toString(response.getEntity());
            return responseText;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // processes result from the server and calls the completion method.
    protected void onPostExecute(String result) {

        listener.ListBuddiesTaskCompletion(result);
    }
}
