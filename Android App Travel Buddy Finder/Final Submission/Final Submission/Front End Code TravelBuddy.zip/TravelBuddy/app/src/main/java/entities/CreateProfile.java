package entities;

/**
 * Created by Preeti
 */
public interface CreateProfile {
    public abstract void createProfile(String name, String contact, String username, String password);
}
