package services.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;
import java.util.List;

import entities.PopulateInformation;
import serviceAPI.UpdateProfile;

/**
 * Created by Preeti
 */
public class UpdateProfileService extends AsyncTask<PopulateInformation,Void,String>{

    private UpdateProfile listener;
    private SharedPreferences sharedPref;

    public UpdateProfileService(UpdateProfile listener) {this.listener = listener;}
    public  void setContext(Context context) {
        sharedPref = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
    }

    protected String doInBackground(PopulateInformation... user) {
        try {
            HttpResponse response = null;
            String localIP = "128.237.202.177";
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair("password", user[0].getU().getPassword()));
            String currentUsername = sharedPref.getString("username", "");
            params.add(new BasicNameValuePair("currentUsername", currentUsername));
            params.add(new BasicNameValuePair("user_input", "changeAccountDetails"));
            StringBuilder requestURL = new StringBuilder("http://"+localIP+":8080/TbBackend/Servlet1?");
            String queryString = URLEncodedUtils.format(params, "utf-8");
            requestURL.append(queryString);
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(requestURL.toString());
            response = client.execute(request);
            String responseText = EntityUtils.toString(response.getEntity());
            return responseText;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // processes result from the server and calls the completion method.
    @Override
    protected void onPostExecute(String s) {
        listener.updateProfileCompletion(s);
    }
}
