package com.nomads.travelbuddy.userinterface;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.nomads.travelbuddy.R;

import org.json.JSONException;
import org.json.JSONObject;

import entities.CreateAuth;
import entities.PopulateInformation;
import exceptions.CustomExceptions;
import serviceAPI.SignIn;
import services.remote.SignInService;

/**
 * Created by Preeti
 */
public class SignInPage extends FragmentActivity implements SignIn {
    /* UI objects as instance variables */
    private EditText username;
    private EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);


        username = (EditText) findViewById(R.id.type_username);
        password = (EditText) findViewById(R.id.type_password);
        String usernameString = username.getText().toString();
        String passwordString = password.getText().toString();

        /*PopulateInformation populateInformation = new PopulateInformation();
        CreateAuth ca = populateInformation;
        ca.createAuth(usernameString, passwordString);*/

    }

    public void signIn(View view) {

        try {
            username = (EditText) findViewById(R.id.type_username);
            password = (EditText) findViewById(R.id.type_password);
            String usernameString = username.getText().toString();
            String passwordString = password.getText().toString();
            if(usernameString.length() == 0 || passwordString.length() == 0)
                throw new CustomExceptions();

            PopulateInformation populateInformation = new PopulateInformation();
            CreateAuth info = populateInformation;
            info.createAuth(usernameString, passwordString);
            SignIn listener = this;
            SignInService runner = new SignInService(listener);
            runner.setContext(getApplicationContext());
            runner.execute(populateInformation);

        } catch (CustomExceptions e) {
            Log.e("exceptions", "Blank username or password");
            e.SigninError(getApplicationContext());
        }
    }
    public void signUp(View view){

        /* intent setup to go to Sign Up page*/
        Intent sign_up_intent = new Intent(this,SignUpPage.class);
        //Toast.makeText(getApplicationContext(), "You're all set to have a wonderful experience with Travel Buddy", Toast.LENGTH_LONG).show();
        startActivity(sign_up_intent);

    }


    public void SignInTaskCompletion (String result) {

        /* intent setup to go to home page*/
        try {
            //Log.i("json", result.toString());
            JSONObject obj = new JSONObject(result);
            String checker = obj.getString("userVerification");
            Log.i("checker", checker.toString());
            if(checker.equals("done")) {
                Intent home_intent = new Intent(SignInPage.this, HomePage.class);
                Toast.makeText(getApplicationContext(), "Welcome to TravelBuddy", Toast.LENGTH_LONG).show();
                startActivity(home_intent);
            }
            else
                throw new CustomExceptions();
        } catch (CustomExceptions e) {
            e.SigninError(getApplicationContext());
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

}
